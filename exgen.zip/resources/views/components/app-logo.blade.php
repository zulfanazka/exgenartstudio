<div class="flex aspect-square size-10 items-center justify-center bg-white rounded-md p-1">
    <img src="{{ asset('images/logo.png') }}" alt="Exgen Art Studio" class="size-16 object-contain" />
</div>
<div class="ms-1 grid flex-1 text-start text-sm">
    <span class="mb-0.5 truncate leading-tight font-semibold text-white">Dashboard Admin</span>
</div>
